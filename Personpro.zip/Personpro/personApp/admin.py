from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Person,Employee

# Register your models here.
class AmdinPerson(admin.ModelAdmin):
    list_display = ['person_id','name','phone','email','crated_date','age','addres','modified_date']
class AdminEmployee(admin.ModelAdmin):
    list_display = ['department','role','line_manager','created_datetime','modified_date']
admin.site.register(Person,AmdinPerson)
admin.site.register(Employee,AdminEmployee)