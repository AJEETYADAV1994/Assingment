from django.db import models

# Create your models here.
from django.db import models
import DateTimeTools,datetime


# Create your models here.
class Person(models.Model):
    person_id=models.IntegerField(unique=True)
    name=models.CharField(unique=True,max_length=25)
    email=models.EmailField(max_length=30)
    age=models.DateField()
    phone=models.BigIntegerField()
    addres=models.CharField(max_length=100)
    crated_date=models.DateTimeField()
    modified_date=models.DateTimeField()

class Employee(models.Model):
    person_id=models.ForeignKey(Person,on_delete=models.CASCADE, blank=True, null=True)
    department=models.CharField(max_length=20)
    role=models.CharField(max_length=25)
    line_manager=models.CharField(max_length=20)
    created_datetime=models.DateTimeField()
    modified_date=models.DateTimeField()

