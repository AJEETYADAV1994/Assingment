from django.urls import path,include
from .views import EmployeeCreateApi,EmployeeApi,EmployeeUpdateApi,EmployeeDeleteApi,\
      PersonCreateApi,PersonApi,PersonUpdateApi,PersopnDeleteApi
urlpatterns = [

    path('Employee/',EmployeeCreateApi.as_view()),
    path('detai',EmployeeApi.as_view()),
    path('api/<int:pk>',EmployeeUpdateApi.as_view()),
    path('api/<int:pk>/delete',EmployeeDeleteApi.as_view()),
    path('',PersonCreateApi.as_view()),
    path('api/',PersonApi.as_view()),
    path('api/Update',PersonUpdateApi.as_view()),
    path('api/Delete',PersopnDeleteApi.as_view())
]