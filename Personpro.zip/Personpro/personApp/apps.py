from django.apps import AppConfig


class PersonappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'personApp'
