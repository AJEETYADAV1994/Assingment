from rest_framework import generics
from rest_framework.response import Response
from .serializers import EmployeeSerializer,PersonSerializer
from .models import Employee,Person
class EmployeeCreateApi(generics.CreateAPIView,generics.ListAPIView,
                        generics.RetrieveUpdateAPIView,generics.DestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
class EmployeeApi(generics.CreateAPIView,generics.ListAPIView,
                        generics.RetrieveUpdateAPIView,generics.DestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
class EmployeeUpdateApi(generics.CreateAPIView,generics.ListAPIView,
                        generics.RetrieveUpdateAPIView,generics.DestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
class EmployeeDeleteApi(generics.CreateAPIView,generics.ListAPIView,
                        generics.RetrieveUpdateAPIView,generics.DestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
class PersonCreateApi(generics.CreateAPIView,generics.ListAPIView,
                      generics.RetrieveUpdateAPIView,generics.DestroyAPIView):
    queryset = Person.objects.all()
    serializer_class = PersonSerializer
class PersonApi(generics.CreateAPIView,generics.ListAPIView,
                      generics.RetrieveUpdateAPIView,generics.DestroyAPIView):
    queryset = Person.objects.all()
    serializer_class = PersonSerializer
class PersonUpdateApi(generics.CreateAPIView,generics.ListAPIView,
                      generics.RetrieveUpdateAPIView,generics.DestroyAPIView):
    queryset = Person.objects.all()
    serializer_class = PersonSerializer
class PersopnDeleteApi(generics.CreateAPIView,generics.ListAPIView,
                      generics.RetrieveUpdateAPIView,generics.DestroyAPIView):
    queryset = Person.objects.all()
    serializer_class = PersonSerializer